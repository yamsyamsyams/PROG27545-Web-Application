package ca.sheridancollege.hoangjam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercise22BonusApplicationTests {

    @Test
    void contextLoads() {
    }

}
