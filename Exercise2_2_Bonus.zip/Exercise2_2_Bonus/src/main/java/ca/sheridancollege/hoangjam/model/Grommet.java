package ca.sheridancollege.hoangjam.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Grommet {
    private String color;
    private String symbol;
}
