package ca.sheridancollege.hoangjam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercise22BonusApplication {

    public static void main(String[] args) {
        SpringApplication.run(Exercise22BonusApplication.class, args);
    }

}
