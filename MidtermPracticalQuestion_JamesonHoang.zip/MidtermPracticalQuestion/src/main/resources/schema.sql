
CREATE TABLE fruit(
	id  int NOT NULL PRIMARY KEY AUTO_INCREMENT,
	fType  varchar(10) NOT NULL,
    weight  int NOT NULL,
    subTotal decimal  NOT NULL
);
