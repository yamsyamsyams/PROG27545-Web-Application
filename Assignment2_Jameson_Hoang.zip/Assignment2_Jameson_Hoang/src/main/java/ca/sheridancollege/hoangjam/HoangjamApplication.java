package ca.sheridancollege.hoangjam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HoangjamApplication {

    public static void main(String[] args) {
        SpringApplication.run(HoangjamApplication.class, args);
    }

}
