INSERT INTO teams (TeamName, Continent, Played, Won, Drawn, Lost) VALUES ('France', 'Europe', 7, 6, 1, 0);
INSERT INTO teams (TeamName, Continent, Played, Won, Drawn, Lost) VALUES ('Belgium', 'Europe', 7, 6, 0, 1);
INSERT INTO teams (TeamName, Continent, Played, Won, Drawn, Lost) VALUES ('Croatia', 'Europe', 7, 4, 2, 1);
INSERT INTO teams (TeamName, Continent, Played, Won, Drawn, Lost) VALUES ('Uruguay', 'S. America', 5, 4, 0, 1);
INSERT INTO teams (TeamName, Continent, Played, Won, Drawn, Lost) VALUES ('Brazil', 'S. America', 5, 3, 1, 0);